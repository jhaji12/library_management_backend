from rest_framework import serializers
from .models import Student, Book, Issue, Faculty
       
class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['name', 'adm_number', 'school_class', 'books_issued']

class FacultySerializer(serializers.ModelSerializer):
    class Meta:
        model = Faculty
        fields = "__all__"

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = ['book_id', 'title', 'author', 'publication', 'vendor', 'edition', 'price']

class IssueSerializer(serializers.ModelSerializer):
    book_id = serializers.IntegerField()
    student_id = serializers.IntegerField()

    class Meta:
        model = Issue
        exclude = ['return_date'] 

    def create(self, validated_data):
        book_id = validated_data.pop('book_id')
        student_id = validated_data.pop('student_id')

        # Retrieve the Book and Student objects using the provided IDs
        try:
            book = Book.objects.get(pk=book_id)
            student = Student.objects.get(pk=student_id)
        except Book.DoesNotExist:
            raise serializers.ValidationError("Book does not exist")
        except Student.DoesNotExist:
            raise serializers.ValidationError("Student does not exist")

        # Create the Issue object with the retrieved Book and Student objects
        issue = Issue.objects.create(book=book, student=student, overdue_amount=validated_data['overdue_amount'])
        return issue


