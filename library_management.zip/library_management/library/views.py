from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Student, Book, Issue, Faculty
from .serializers import StudentSerializer, BookSerializer, IssueSerializer, FacultySerializer
from rest_framework.pagination import PageNumberPagination
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout

class MyPagination(PageNumberPagination):
    page_size = 10  # Set the number of items per page

class UserLoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        print(username, password)
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return Response({"message": "Login successful"}, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

class UserLogoutView(APIView):
    def post(self, request):
        logout(request)
        return Response({"message": "Logout successful"}, status=status.HTTP_200_OK)
    
class StudentCreateView(generics.CreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
class StudentListView(generics.ListAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    pagination_class = MyPagination

class StudentDetailView(generics.RetrieveAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    lookup_field = 'adm_number'

class StudentDeleteView(generics.DestroyAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    lookup_field = 'adm_number'

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response({"message": "Student deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

class FacultyCreateView(generics.CreateAPIView):
    queryset = Faculty.objects.all()
    serializer_class = FacultySerializer
    
class FacultyListView(generics.ListAPIView):
    queryset = Faculty.objects.all()
    serializer_class = FacultySerializer
    pagination_class = MyPagination

class FacultyDetailView(generics.RetrieveAPIView):
    queryset = Faculty.objects.all()
    serializer_class = FacultySerializer
    lookup_field = 'faculty_id'

class FacultyDeleteView(generics.DestroyAPIView):
    queryset = Faculty.objects.all()
    serializer_class = FacultySerializer
    lookup_field = 'faculty_id'

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response({"message": "Faculty deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

class BookCreateView(generics.CreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookListView(generics.ListAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    pagination_class = MyPagination

class BookDetailView(generics.RetrieveAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    lookup_field = 'book_id'

class BookDeleteView(generics.DestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    lookup_field = 'book_id'

    def destroy(self, request, *args, **kwargs):
        book = self.get_object()
        # Check if there are any issued copies of the book
        issued_copies = Issue.objects.filter(book=book, returned=False).exists()
        if issued_copies:
            return Response({"error": "Cannot delete book. There are issued copies."}, status=status.HTTP_400_BAD_REQUEST)

        # If no issued copies, delete the book and its associated copies
        book.delete()

        return Response({"message": "Book and associated copies deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

class IssueBookView(generics.CreateAPIView):
    serializer_class = IssueSerializer

    def create(self, request, *args, **kwargs):
        book_id = request.data.get('book_id')
        student_id = request.data.get('student_id')

        try:
            book = Book.objects.get(id=book_id)
            student = Student.objects.get(id=student_id)
        except Book.DoesNotExist:
            return Response({"error": "Book not found"}, status=status.HTTP_404_NOT_FOUND)
        except Student.DoesNotExist:
            return Response({"error": "Student not found"}, status=status.HTTP_404_NOT_FOUND)

        # Check if the same book is already issued to the same student
        if Issue.objects.filter(book=book, student=student, returned=False).exists():
            return Response({"error": "The book is already issued to the student"}, status=status.HTTP_400_BAD_REQUEST)

        if book.available_copies <= 0:
            return Response({"error": "No available copies of the book"}, status=status.HTTP_400_BAD_REQUEST)

        if student.books_issued.count() >= student.max_books_allowed:
            return Response({"error": "Student has already reached the maximum limit of books allowed to issue"}, status=status.HTTP_400_BAD_REQUEST)

        issue = Issue(book=book, student=student)
        issue.save()

        book.available_copies -= 1
        book.save()

        serializer = self.get_serializer(issue)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class ReturnBookView(generics.UpdateAPIView):
    queryset = Issue.objects.all()
    serializer_class = IssueSerializer

    def update(self, request, *args, **kwargs):
        # Retrieve book_id and student_id from the request data
        book_id = request.data.get('book_id')
        student_id = request.data.get('student_id')

        # Check if both book_id and student_id are provided
        if not book_id or not student_id:
            return Response({"error": "Both book_id and student_id must be provided"}, status=status.HTTP_400_BAD_REQUEST)

        # Retrieve the issue object based on book_id, student_id, and not returned
        try:
            issue = Issue.objects.get(book_id=book_id, student_id=student_id, returned=False)
        except Issue.DoesNotExist:
            return Response({"error": "Issue not found for the provided book and student"}, status=status.HTTP_404_NOT_FOUND)

        # Calculate overdue amount if return date is in the past
        if issue.return_date and issue.return_date < timezone.now().date():
            days_overdue = (timezone.now().date() - issue.return_date).days
            overdue_fee_per_day = 5  # Adjust as needed
            issue.overdue_amount = days_overdue * overdue_fee_per_day

        # Update the instance to mark the book as returned
        issue.returned = True
        issue.save()

        # Increment the available_copies of the associated book
        book = issue.book
        book.available_copies += 1
        book.save()

        return Response({"message": "Book returned successfully"}, status=status.HTTP_200_OK)

